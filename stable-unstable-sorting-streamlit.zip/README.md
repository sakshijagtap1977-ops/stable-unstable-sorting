# Employee Sorting Demonstrator

A Streamlit app that demonstrates stable sorting and swap-based selection sort using employee records.

## Files
- `app.py` — Streamlit application
- `requirements.txt` — Python dependencies

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Render
Create a **Web Service** connected to this repository and use:

- Runtime/Language: Python
- Build Command: `pip install -r requirements.txt`
- Start Command: `streamlit run app.py --server.address 0.0.0.0 --server.port $PORT --server.headless true`

The app must be deployed as a Web Service, not a Static Site, because Streamlit runs a Python web server.
